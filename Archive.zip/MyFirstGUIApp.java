/*
Jemma Tiongson
Section #16031
App: Driver.java (MyFirstGUI App)
Purpose: Demonstrate GUI
-------------------------------------------------------------------------

Terminal:
   Compile: javac Driver.java MyFirstGUIApp.java
   Run: java Driver
_________________________________________________________________________
*/
import javax.swing.JFrame;
import javax.swing.JLabel;

public class MyFirstGUIApp{
   //constructor
   public MyFirstGUIApp(){
      initComponents();
   }
   private void initComponents(){
      //new frame with title
      JFrame frame = new JFrame ("My First GUI Application");
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      
      //label to GUI
      JLabel label = new JLabel("Jemma's First GUI App :)");
      frame.getContentPane().add(label);
      
      //show GUI
      frame.pack();
      frame.setVisible(true);
   }
}